// app/Http/Controllers/PedidoController.php
namespace App\Http\Controllers;

use App\Models\Pedido;
use Illuminate\Http\Request;

class PedidoController extends Controller {
    public function index() {
        $pedidos = Pedido::orderBy('created_at', 'desc')->get();
        return view('pedidos.index', compact('pedidos'));
    }
    // app/Http/Controllers/PedidoController.php
namespace App\Http\Controllers;

class PedidoController extends Controller {
    public function index() {
        $pedidos = Pedido::orderBy('created_at', 'desc')->get();
        return view('pedidos.index', compact('pedidos'));
    }

    public function create() {
        return view('pedidos.create');
    }

    public function store(Request $request) {
        // Lógica para almacenar un nuevo pedido
    }

    public function edit($id) {
        $pedido = Pedido::findOrFail($id);
        return view('pedidos.edit', compact('pedido'));
    }

    public function update(Request $request, $id) {
        // Lógica para actualizar un pedido existente
    }

    public function changeStatus(Request $request, $id) {
        // Lógica para cambiar el estado del pedido
    }

    public function captureEvidence(Request $request, $id) {
        // Lógica para capturar evidencia dependiendo del estado del pedido
    }

    public function show($id) {
        $pedido = Pedido::findOrFail($id);
        return view('pedidos.show', compact('pedido'));
    }

    public function destroy($id) {
        // Lógica para eliminar un pedido (lógicamente)
    }
}
