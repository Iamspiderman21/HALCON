// app/Models/Pedido.php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pedido extends Model {
    protected $fillable = ['cliente_id', 'estado', 'fecha_entrega', 'foto_entrega'];

    public function cliente() {
        return $this->belongsTo(Cliente::class);
    }
}