<!-- resources/views/layouts/app.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Head section -->
</head>
<body>
    <!-- Navigation -->
    <nav>
        <ul>
            <li><a href="{{ route('dashboard') }}">Panel de Control</a></li>
            <!-- Otros enlaces de navegación -->
        </ul>
    </nav>

    <!-- Content -->
    @yield('content')
</body>
</html>
