@foreach($clientes as $cliente)
    <p>{{ $cliente->nombre }} - {{ $cliente->email }}</p>
@endforeach
