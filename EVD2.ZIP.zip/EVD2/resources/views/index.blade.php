<!-- resources/views/dashboard/index.blade.php -->
@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Panel de Control</div>

                    <div class="card-body">
                        <ul>
                            <li><a href="{{ route('users.index') }}">Gestión de Usuarios</a></li>
                            <li><a href="{{ route('pedidos.index') }}">Gestión de Pedidos</a></li>
                            <!-- Otros enlaces según sea necesario -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
<!-- resources/views/pedidos/index.blade.php -->
@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Listado de Pedidos</h1>
        <a href="{{ route('pedidos.create') }}" class="btn btn-primary mb-3">Crear Pedido</a>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Estado</th>
                    <th>Fecha de Entrega</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach($pedidos as $pedido)
                    <tr>
                        <td>{{ $pedido->id }}</td>
                        <td>{{ $pedido->estado }}</td>
                        <td>{{ $pedido->fecha_entrega }}</td>
                        <td>
                            <a href="{{ route('pedidos.show', $pedido->id) }}" class="btn btn-info btn-sm">Ver</a>
                            <a href="{{ route('pedidos.edit', $pedido->id) }}" class="btn btn-primary btn-sm">Editar</a>
                            <form action="{{ route('pedidos.destroy', $pedido->id) }}" method="POST" style="display: inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de querer eliminar este pedido?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
