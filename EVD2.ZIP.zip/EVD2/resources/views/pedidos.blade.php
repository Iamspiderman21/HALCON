@foreach($pedidos as $pedido)
    <p>{{ $pedido->id }} - {{ $pedido->estado }}</p>
@endforeach
