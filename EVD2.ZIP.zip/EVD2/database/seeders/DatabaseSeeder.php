<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        User::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]);
    }
}
// database/seeders/DatabaseSeeder.php
use Illuminate\Database\Seeder;
use App\Models\Cliente;
use App\Models\Pedido;

class DatabaseSeeder extends Seeder {
    public function run() {
        Cliente::factory(10)->create()->each(function ($cliente) {
            $cliente->pedidos()->saveMany(Pedido::factory(3)->make());
        });
    }
}